import csv
# maths_file = open('Teacher wise class timetable - Maths.xlsx - Teacher wise class timetable - .csv')
# csv_mathsfile = csv.reader(maths_file)

# science_file = open('Teacher wise class timetable - Science.xlsx - Teacher wise class timetable - .csv')
# csv_sciencefile = csv.reader(science_file)

# kannada_file = open('Teacher wise class timetable - Kannada.xlsx - Teacher wise class timetable - .csv')
# csv_kannadafile = csv.reader(kannada_file)

# hindi_file = open('Teacher wise class timetable - Hindi.xlsx - Teacher wise class timetable - .csv')
# csv_hindifile = csv.reader(hindi_file)

# english_file = open('Teacher wise class timetable - English.xlsx - Teacher wise class timetable - .csv')
# csv_englishfile = csv.reader(english_file)

days = ['--', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
rows_of_10th_class = [['8:00 AM', 'Hindi', 'Kannada', 'English', 'Science', 'Maths', '' ],
                      ['9:00 AM', '', 'Hindi', 'Kannada', 'English', 'Science', 'Maths'],
                      ['10:00 AM', '', '', 'Hindi', 'Kannada', 'English', 'Science'],
                      ['11:00 AM', '', '', '', 'Hindi', 'Kannada', 'English'],
                      ['12:00 PM', '', '', '', '', 'Hindi', 'Kannada'],
                      ['1:00 PM', 'Maths', '', '', '', '', 'Hindi'],
                      ['2:00 PM', 'Science', 'Maths', '', '', '', ''],
                      ['3:00 PM', 'English', 'Science', 'Maths', '', '', ''],
                      ['4:00 PM', 'Kannada', 'English', 'Science', 'Maths', '', '']]
filename = "class 10 timetable.csv"
  
with open(filename, 'w') as csvfile:
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(days) 
    csvwriter.writerows(rows_of_10th_class)

rows_of_9th_class = [['8:00 AM', '', 'Hindi', 'Kannada', 'English', 'Science', 'Maths' ],
                      ['9:00 AM', '', '', 'Hindi', 'Kannada', 'English', 'Science'],
                      ['10:00 AM', '', '', '', 'Hindi', 'Kannada', 'English'],
                      ['11:00 AM', '', '', '', '', 'Hindi', 'Kannada'],
                      ['12:00 PM', 'Maths', '', '', '', '', 'Hindi'],
                      ['1:00 PM', 'Science', 'Maths', '', '', '', ''],
                      ['2:00 PM', 'English', 'Science', 'Maths', '', '', ''],
                      ['3:00 PM', 'Kannada', 'English', 'Science', 'Maths', '', ''],
                      ['4:00 PM', 'Hindi', 'Kannada', 'English', 'Science', 'Maths', '']]

filename = "class 9 timetable.csv"
  
with open(filename, 'w') as csvfile:
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(days) 
    csvwriter.writerows(rows_of_9th_class)

rows_of_8th_class = [['8:00 AM', '', '', 'Hindi', 'Kannada', 'English', 'Science' ],
                      ['9:00 AM', '', '', '', 'Hindi', 'Kannada', 'English'],
                      ['10:00 AM', '', '', '', '', 'Hindi', 'Kannada'],
                      ['11:00 AM', 'Maths', '', '', '', '', 'Hindi'],
                      ['12:00 PM', 'Science', 'Maths', '', '', '', ''],
                      ['1:00 PM', 'English', 'Science', 'Maths', '', '', ''],
                      ['2:00 PM', 'Kannada', 'English', 'Science', 'Maths', '', ''],
                      ['3:00 PM', 'Hindi', 'Kannada', 'English', 'Science', 'Maths', ''],
                      ['4:00 PM', '', 'Hindi', 'Kannada', 'English', 'Science', 'Maths']]

filename = "class 8 timetable.csv"
  
with open(filename, 'w') as csvfile:
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(days) 
    csvwriter.writerows(rows_of_8th_class)

rows_of_7th_class = [['8:00 AM', '', '', '', 'Hindi', 'Kannada', 'English' ],
                      ['9:00 AM', '', '', '', '', 'Hindi', 'Kannada'],
                      ['10:00 AM', 'Maths', '', '', '', '', 'Hindi'],
                      ['11:00 AM', 'Science', 'Maths', '', '', '', ''],
                      ['12:00 PM', 'English', 'Science', 'Maths', '', '', ''],
                      ['1:00 PM', 'Kannada', 'English', 'Science', 'Maths', '', ''],
                      ['2:00 PM', 'Hindi', 'Kannada', 'English', 'Science', 'Maths', ''],
                      ['3:00 PM', '', 'Hindi', 'Kannada', 'English', 'Science', 'Maths'],
                      ['4:00 PM', '', '', 'Hindi', 'Kannada', 'English', 'Science']]

filename = "class 7 timetable.csv"
  
with open(filename, 'w') as csvfile:
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(days) 
    csvwriter.writerows(rows_of_7th_class)

rows_of_6th_class = [['8:00 AM', '', '', '', '', 'Hindi', 'Kannada' ],
                      ['9:00 AM', 'Maths', '', '', '', '', 'Hindi'],
                      ['10:00 AM', 'Science', 'Maths', '', '', '', ''],
                      ['11:00 AM', 'English', 'Science', 'Maths', '', '', ''],
                      ['12:00 PM', 'Kannada', 'English', 'Science', 'Maths', '', ''],
                      ['1:00 PM', 'Hindi', 'Kannada', 'English', 'Science', 'Maths', ''],
                      ['2:00 PM', '', 'Hindi', 'Kannada', 'English', 'Science', 'Maths'],
                      ['3:00 PM', '', '', 'Hindi', 'Kannada', 'English', 'Science'],
                      ['4:00 PM', '', '', '', 'Hindi', 'Kannada', 'English']]

filename = "class 6 timetable.csv"
  
with open(filename, 'w') as csvfile:
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(days) 
    csvwriter.writerows(rows_of_6th_class)

